CREATE TRIGGER trg_last_update_location
ON location
AFTER UPDATE
AS
BEGIN
   UPDATE location
   SET last_update = GETDATE()
   FROM location lk
   INNER JOIN inserted i ON lk.LocationID = lk.LocationID;
END