CREATE TRIGGER trg_last_update_borrower
ON borrower
AFTER UPDATE
AS
BEGIN
   UPDATE borrower
   SET last_update = GETDATE()
   FROM borrower bo
   INNER JOIN inserted i ON bo.CardNum = i.CardNum;
END