CREATE TRIGGER trg_last_update_branch
ON library_branch
AFTER UPDATE
AS
BEGIN
   UPDATE library_branch
   SET last_update = GETDATE()
   FROM library_branch lb
   INNER JOIN inserted i ON lb.BranchID = i.BranchID;
END

DROP TRIGGER trg_last_update_branch;
