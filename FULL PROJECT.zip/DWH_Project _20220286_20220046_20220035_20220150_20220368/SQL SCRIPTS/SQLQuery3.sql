CREATE TRIGGER trg_last_update_book
ON book
AFTER UPDATE
AS
BEGIN
   UPDATE book
   SET last_update = GETDATE()
   FROM book bk
   INNER JOIN inserted i ON bk.BookID = i.BookID;
END