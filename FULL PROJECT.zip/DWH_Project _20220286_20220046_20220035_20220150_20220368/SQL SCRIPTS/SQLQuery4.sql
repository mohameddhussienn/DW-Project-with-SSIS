CREATE TRIGGER trg_last_update_author
ON author
AFTER UPDATE
AS
BEGIN
   UPDATE author
   SET last_update = GETDATE()
   FROM author ah
   INNER JOIN inserted i ON ah.AuthorID = ah.AuthorID;
END